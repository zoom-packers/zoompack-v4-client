const fs = require('fs');
const classesGeometry = require('./classes.geo.json')

const classesNames = [
    "archer",
    "beastmaster",
    "blacksmith",
    "cleric",
    "cook",
    "farmer",
    "lumberjack",
    "merchant",
    "miner",
    "rancher",
    "rogue",
    "warrior",
]

const textureOverrides = {
    "warriror": "archer",
    "rogue": "lumberjack",
    "miner": "blacksmith",
}

const root = classesGeometry["minecraft:geometry"][0];
const formatVersion = classesGeometry.format_version;
const description = root.description;

const rootBones = root.bones.filter(bone => classesNames.includes(bone.name));

function findAllRelatedBones(currentBone, allBonesInClass) {
    for (const rootBone of root.bones) {
        if (rootBone.parent === currentBone.name) {
            allBonesInClass.push(rootBone);
            findAllRelatedBones(rootBone, allBonesInClass);
        }
    }
}

const classesBonesJsons = {};
for (const classesName of classesNames) {
    const allBonesInClass = [];
    const rootBoneForClass = rootBones.find(bone => bone.name === classesName);
    allBonesInClass.push(rootBoneForClass);
    findAllRelatedBones(rootBoneForClass, allBonesInClass);
    rootBoneForClass.name = "bipedBody";
    for (const bone of allBonesInClass) {
        if (bone.parent === classesName) {
            bone.parent = "bipedBody";
        }
    }
    classesBonesJsons[classesName] = {
        format_version: formatVersion,
        "minecraft:geometry": [{
            description,
            bones: allBonesInClass
        }]
    }
}

for (const [className, classBonesJson] of Object.entries(classesBonesJsons)) {
    fs.writeFileSync(`./${className}.geo.json`, JSON.stringify(classBonesJson, null, 4));
}
